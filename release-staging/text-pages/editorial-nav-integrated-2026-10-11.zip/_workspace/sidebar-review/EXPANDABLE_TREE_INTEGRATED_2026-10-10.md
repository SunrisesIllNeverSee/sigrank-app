# Approved expandable navigation integrated — 2026-10-10

Branch: feat/live-board-2b. Local only; no commit, push or deployment.
Working preview: http://127.0.0.1:61173/

Final state:
- SigRank Landing Zero: 5 topics, then in-page contents on SigRank selection.
- Wiki: original single-page table-of-contents navigation.
- Field / Articles / Blog: real document lists and active inline section indexes.
- Native expanded/collapsed state and sibling links do not rely on client hydration.
- Back/Home at end of full tree (after About within Field).
- Static Blog anchor fallback derives links from actual page headings.
- All existing content, calculations, telemetry, themes, wordmarks,
  stage, right sidebar and unrelated in-flight repository work preserved.

Scoped code:
components/live/EditorialSidebar.tsx; components/live/proto-scoped.css;
components/blog/BlogWorkspaceFrame.tsx; app/articles/page.tsx;
app/blog/page.tsx; lib/editorial/blog-index.ts;
lib/editorial/workspace-documents.ts.

Validation: TypeScript PASS, ESLint PASS, git diff --check PASS,
155 UI tests PASS, 11 canonical tests PASS, browser route and
responsive checks PASS.
